import sqlite3


print("Hello am oliver the condor")


name1 = 'olivier'
passwor = 1234

name = input("Enter your name.\n>>")
password = input("Enter your password\n>>")

if name == name1 and password == passwor:
    print("Welcome to our database")
    
else:
    print("Something went wrong, try again.")
    
    
conn = sqlite3.connect('olivier.db')
cursor = conn.cursor()
cursor.execute('DROPE TABLE ACC IF EXISTS')

sql = """CREATE TABLE ACC(
    ID INT(10) NOT NULL,
    FIRST_NAME CHAR(20) NOT NULL,
    LAST_NAME CHAR(20) NOT NULL,
    AGE INT(10),
    SEX CHAR(5),
    PRIMARY KEY(ID)
    )"""
    
cursor.execute(sql)
print("Table create well.....")


cursor.execute("""INSERT INTO ACC(ID, FIRST_NAME, LAST_NAME, AGE, SEX)
               VALUES('TWIZERIMANA', 'Olivier', 23, 'M')""")
cursor.execute("""INSERT INTO ACC(ID, FIRST_NAME, LAST_NAME, AGE, SEX)
               VALUES('TWIZERIMANA', 'Olivier', 23, 'M')""")
cursor.execute("""INSERT INTO ACC(ID, FIRST_NAME, LAST_NAME, AGE, SEX)
               VALUES('TWIZERIMANA', 'Olivier', 23, 'M')""")
cursor.execute("""INSERT INTO ACC(ID, FIRST_NAME, LAST_NAME, AGE, SEX)
               VALUES('TWIZERIMANA', 'Olivier', 23, 'M')""")
cursor.execute("""INSERT INTO ACC(ID, FIRST_NAME, LAST_NAME, AGE, SEX)
               VALUES('TWIZERIMANA', 'Olivier', 23, 'M')""")


print('Data inserted well......')

cursor.execute('SELECT * FROM ACC')
cursor.fetchall()
conn.commit()
conn.close()
